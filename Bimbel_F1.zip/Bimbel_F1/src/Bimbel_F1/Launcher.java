/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bimbel_F1;

/**
 *
 * @author soeha
 */
public class Launcher {

  

/**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Splash s = new Splash();
        s.setVisible(true);
        try {
            for(int i=0;i<=100;i++){
                Thread.sleep(60);
                s.jbar.setStringPainted(true);
                s.jbar.setValue(i);
                if(i==100){
                    LoginPanel c = new LoginPanel();
                    c.setVisible(true);
                    s.dispose(); }
            }
        }
        catch(Exception e){
            
        }
    }
    
}

